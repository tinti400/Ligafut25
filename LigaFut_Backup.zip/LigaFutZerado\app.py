# Arquivo principal do Streamlit

import streamlit as st

st.set_page_config(page_title='LigaFut', layout='wide')
st.title('🏆 LigaFut 2025')
st.markdown('Acesse o menu lateral para navegar pelo sistema.')
